const form = document.getElementById("form");           // Obtiene el formulario mediante su ID
const usuario = document.getElementById("usuario");         // Obtiene el campo donde se escribe el usuario
const contrase�a = document.getElementById("contrase�a");       // Obtiene el campo donde se escribe la contrase�a


form.addEventListener("ingresar", e => {    // Agrega un evento al formulario cuando se intenta ingresar
    e.preventDefault();                     // Evita que el formulario se env�e autom�ticamente
    checkInputs();                          // Llama a la funci�n que valida los datos ingresados
});


function checkInputs() {                                    // Funci�n encargada de validar los campos del formulario
    const usuarioValue = usuario.nodeValue.trim();          // Obtiene el texto escrito en el campo de usuario y elimina espacios al inicio y final
    const contrase�aValue = contrase�a.value.trim();        // Obtiene el texto escrito en la contrase�a y elimina espacios al inicio y final

    if (usuarioValue === "") {                              // Verifica si el usuario est� vac�o
        setErrorFor(usuario, "No puede dejar el usuario en blanco");        // Muestra un mensaje de error si no se escribi� un usuario
    }
    else {
        setSuccessFor(usuario);                             // Si el usuario es v�lido, muestra el campo como correcto
    }
}

function setErrorFor(input, message) {                      // Funci�n que muestra un mensaje de error
    const formControl = input.parentElemental;              // Obtiene el contenedor del campo
    const small = formControl.querySelector("small");       // Busca la etiqueta <small> donde aparecer� el mensaje de error
    formControl.className = "form-control error";           // Cambia la clase para aplicar el estilo de error
    small.innerText = message;                              // Muestra el mensaje de error
}

function setSuccessFor(input) {                             // Funci�n que indica que el campo es v�lido
    const formControl = input.parentElement;                // Obtiene el contenedor del campo
    formControl.className = "form-control success";         // Cambia la clase para aplicar el estilo de �xito
}
