<script></script>       // Etiqueta para incluir c�digo JavaScript dentro del documento HTML


// Funci�n que se ejecuta al registrar un usuario
function Registro() {

    var pass1 = document.getElementById('password').value;          // Obtiene la contrase�a ingresada por el usuario
    var name = document.getElementById("name").value;               // Obtiene el nombre del usuario
    var email = document.getElementById("email").value;             // Obtiene el correo electr�nico
    var user = document.getElementById("username").value;           // Obtiene el nombre de usuario

    var now = new Date();                       // Obtiene la fecha actual
    var currentY = now.getFullYear();           // Obtiene el a�o actual
    var currentM = now.getMonth();              // Obtiene el mes actual

    var dobget = document.getElementById("nacimiento").value;        // Obtiene la fecha de nacimiento ingresada por el usuario
    var dob = new Date(dobget);                                      // Convierte la fecha de nacimiento en un objeto Date
    var prevY = dob.getFullYear();                                   // Obtiene el a�o de nacimiento
    var prevM = dob.getMonth();                                      // Obtiene el mes de nacimiento

    var ageY = currentY - prevY;                                     // Calcula la diferencia de a�os entre la fecha actual y la de nacimiento
    var ageM = Math.abs(currentM - prevM);                           // Calcula la diferencia de meses


    // Verifica si el usuario es menor de edad
    if (ageY < 18) {
        alert("Necesitas 18 a�os")      // Muestra un mensaje indicando que debe ser mayor de edad
        return;                         // Detiene la ejecuci�n de la funci�n
    }


    // Verifica que ambas contrase�as sean iguales
    if (pass1 != pass2) {
        alert("Las contrase�as no coinciden");      // Muestra un mensaje si las contrase�as no coinciden

    }

}


// Funci�n para comprobar que la contrase�a de confirmaci�n sea igual a la original
function check() {
    var input = document.getElementById('confcontrase�a');                  // Obtiene el campo donde se confirma la contrase�a
    if (input.value != document.getElementById('contrase�a').value) {       // Compara la contrase�a confirmada con la contrase�a original
        input.setCustomValidity('Password Must be Matching.');              // Muestra un mensaje de error de validaci�n si son diferentes
    } else {
        // input is valid -- reset the error message
        input.setCustomValidity('');                                        // Si las contrase�as coinciden, elimina el mensaje de error
    }
}