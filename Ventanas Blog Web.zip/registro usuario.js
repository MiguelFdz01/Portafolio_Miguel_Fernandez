// Etiqueta para incluir c�digo JavaScript dentro del documento HTML
<script></script>

// Funci�n que realiza las validaciones del formulario de registro
function Registro() {

    // Obtiene la contrase�a escrita por el usuario
    var pass1 = document.getElementById('password').value;

    // Obtiene la confirmaci�n de la contrase�a
    var pass2 = document.getElementById("password2").value;

    // Obtiene el nombre del usuario
    var name = document.getElementById("name").value;

    // Obtiene el apellido paterno
    var Paterno = document.getElementById("apellidoP").value;

    // Obtiene el apellido materno
    var Materno = document.getElementById("apellidoM").value;

    // Obtiene el correo electr�nico
    var email = document.getElementById("email").value;

    // Obtiene el nombre de usuario
    var user = document.getElementById("username").value;


    // Obtiene la fecha actual del sistema
    var now = new Date();

    // Guarda el a�o actual
    var currentY = now.getFullYear();

    // Guarda el mes actual
    var currentM = now.getMonth();


    // Obtiene la fecha de nacimiento ingresada
    var dobget = document.getElementById("nacimiento").value;

    // Convierte la fecha de nacimiento a un objeto Date
    var dob = new Date(dobget);

    // Obtiene el a�o de nacimiento
    var prevY = dob.getFullYear();

    // Obtiene el mes de nacimiento
    var prevM = dob.getMonth();


    // Calcula la edad aproximada en a�os
    var ageY = currentY - prevY;

    // Calcula la diferencia de meses
    var ageM = Math.abs(currentM - prevM);


    // Verifica que el usuario tenga al menos 18 a�os
    if (ageY < 18) {
        alert("Necesitas 18 a�os");
        return; // Detiene la ejecuci�n de la funci�n
    }


    // Comprueba que ambas contrase�as sean iguales
    if (pass1 != pass2) {
        alert("Las contrase�as no coinciden");
    }

}


// Funci�n que valida en tiempo real que las contrase�as coincidan
function check() {

    // Obtiene el campo de confirmaci�n de contrase�a
    var input = document.getElementById('confcontrase�a');

    // Compara la contrase�a original con la confirmaci�n
    if (input.value != document.getElementById('contrase�a').value) {

        // Muestra un mensaje de error personalizado si son diferentes
        input.setCustomValidity('Password Must be Matching.');

    } else {

        // Si coinciden, elimina el mensaje de error
        input.setCustomValidity('');
    }
}