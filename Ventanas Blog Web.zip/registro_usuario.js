// Funci�n que valida la informaci�n del formulario de registro
function Registro() {

    // Obtiene el valor de la contrase�a
    var contrase�a = document.getElementById('contrase�a').value;

    // Obtiene el valor de la confirmaci�n de contrase�a
    var confcontrase�a = document.getElementById("confcontrase�a").value;

    // Obtiene el nombre del usuario
    var nombre = document.getElementById("nombre").value;

    // Obtiene los apellidos del usuario
    var apellidos = document.getElementById("apellidos").value;

    // Obtiene el correo electr�nico
    var correo = document.getElementById("correo").value;

    // Obtiene el nombre de usuario
    var usuario = document.getElementById("usuario").value;


    // Obtiene la fecha actual del sistema
    var now = new Date();

    // Guarda el a�o actual
    var currentY = now.getFullYear();

    // Guarda el mes actual
    var currentM = now.getMonth();


    // Obtiene la fecha de nacimiento seleccionada en el formulario
    var dobget = document.getElementById("nacimiento").value;

    // Convierte la fecha de nacimiento en un objeto Date
    var dob = new Date(dobget);

    // Obtiene el a�o de nacimiento
    var prevY = dob.getFullYear();

    // Obtiene el mes de nacimiento
    var prevM = dob.getMonth();


    // Calcula la diferencia de a�os entre la fecha actual y la fecha de nacimiento
    var ageY = currentY - prevY;

    // Calcula la diferencia de meses
    var ageM = Math.abs(currentM - prevM);


    // Verifica que el usuario sea mayor de edad
    if (ageY < 18) {
        alert("Necesitas ser mayor de 18 a�os");
        return; // Detiene la ejecuci�n de la funci�n
    }


    // Comprueba que ambas contrase�as sean iguales
    if (contrase�a != confcontrase�a) {
        alert("Las contrase�as no coinciden");
    }

}


// Funci�n que valida en tiempo real que ambas contrase�as coincidan
function check() {

    // Obtiene el campo de confirmaci�n de contrase�a
    var input = document.getElementById('confcontrase�a');

    // Compara el valor escrito con la contrase�a original
    if (input.value != document.getElementById('contrase�a').value) {

        // Muestra un mensaje de error personalizado si no coinciden
        input.setCustomValidity('Password Must be Matching.');

    } else {

        // Si coinciden, elimina el mensaje de error y permite enviar el formulario
        input.setCustomValidity('');
    }
}