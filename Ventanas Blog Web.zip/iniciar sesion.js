// Obtiene el formulario mediante su id
const form = document.getElementById("form");

// Obtiene el campo de usuario
const usuario = document.getElementById("usuario");

// Obtiene el campo de contrase�a
const contrase�a = document.getElementById("contrase�a");

// Agrega un evento al formulario cuando se intenta enviar
// Nota: "ingresar" no es un evento v�lido. Normalmente debe ser "submit".
form.addEventListener("ingresar", e => {

    // Evita que el formulario se env�e autom�ticamente
    e.preventDefault();

    // Llama a la funci�n que valida los datos
    checkInputs();
});


// Funci�n que verifica si los campos contienen informaci�n v�lida
function checkInputs() {

    // Obtiene el texto del usuario eliminando espacios al inicio y final
    // Nota: deber�a usarse usuario.value y no usuario.nodeValue.
    const usuarioValue = usuario.nodeValue.trim();

    // Obtiene la contrase�a eliminando espacios innecesarios
    const contrase�aValue = contrase�a.value.trim();

    // Comprueba si el usuario est� vac�o
    if (usuarioValue === "") {

        // Muestra un mensaje de error
        setErrorFor(usuario, "No puede dejar el usuario en blanco");

    } else {

        // Indica que el campo es v�lido
        setSuccessFor(usuario);
    }
}


// Funci�n que muestra un error en un campo del formulario
function setErrorFor(input, message) {

    // Obtiene el contenedor del campo
    // Nota: parentElemental no existe. Debe ser parentElement.
    const formControl = input.parentElemental;

    // Busca la etiqueta <small> donde se mostrar� el mensaje
    const small = formControl.querySelector("small");

    // Cambia la clase para mostrar el estilo de error
    formControl.className = "form-control error";

    // Escribe el mensaje de error
    small.innerText = message;
}


// Funci�n que indica que un campo es v�lido
function setSuccessFor(input) {

    // Obtiene el contenedor del campo
    const formControl = input.parentElement;

    // Cambia la clase para mostrar el estilo de �xito
    formControl.className = "form-control success";
}