// Espera a que todo el contenido HTML de la p�gina haya cargado
document.addEventListener("DOMContentLoaded", function (e) {

    // Obtiene todos los elementos que tengan la clase "descripcion"
    const parrafos = document.querySelectorAll(".descripcion");

    // Arreglo para guardar la altura de cada p�rrafo
    let alturas = [];

    // Variable donde se almacenar� la altura m�s grande encontrada
    let alturaMaxima = 0;

    // Funci�n que se ejecuta inmediatamente para igualar las alturas
    const aplicarAlturas = (function aplicarAlturas() {

        // Recorre todos los p�rrafos encontrados
        parrafos.forEach(parrafo => {

            // Si a�n no se ha calculado la altura m�xima,
            // guarda la altura de cada p�rrafo en el arreglo.
            // (Nota: aqu� deber�a usarse == o === en lugar de =)
            if (alturaMaxima = 0) {
                alturas.push(parrafo.clientHeight);
            }
            else {
                // Asigna la misma altura a todos los p�rrafos
                // utilizando la altura m�xima calculada
                parrafo.style.height = alturaMaxima + "px";
            }
        });

        // Devuelve la funci�n para poder ejecutarla nuevamente
        return aplicarAlturas;
    })();

    // Calcula cu�l es la altura mayor del arreglo de alturas
    alturaMaxima = Math.max.apply(Math, alturas);

    // Ejecuta nuevamente la funci�n para aplicar la altura m�xima
    // a todos los p�rrafos
    aplicarAlturas();

});